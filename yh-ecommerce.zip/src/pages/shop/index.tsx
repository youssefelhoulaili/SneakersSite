import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
import { GetStaticProps } from 'next';
import Layout from '../../components/Layout';
import { useState } from 'react';
import Link from 'next/link';

export default function Shop() {
  const { t } = useTranslation('common');
  const [activeFilters, setActiveFilters] = useState<Record<string, string>>({});
  const [sortBy, setSortBy] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);

  // Sample products data
  const products = [
    {
      id: 1,
      name: 'YH Air Max',
      price: 1299,
      image: '/images/products/shoes-1.jpg',
      category: 'running',
      sport: 'running',
      gender: 'men'
    },
    {
      id: 2,
      name: 'YH Pro Training',
      price: 899,
      image: '/images/products/shoes-2.jpg',
      category: 'training',
      sport: 'training',
      gender: 'women'
    },
    {
      id: 3,
      name: 'YH Basketball Elite',
      price: 1499,
      image: '/images/products/shoes-3.jpg',
      category: 'basketball',
      sport: 'basketball',
      gender: 'men'
    },
    {
      id: 4,
      name: 'YH Lifestyle',
      price: 999,
      image: '/images/products/shoes-4.jpg',
      category: 'lifestyle',
      sport: 'lifestyle',
      gender: 'unisex'
    },
    {
      id: 5,
      name: 'YH Football Cleats',
      price: 1199,
      image: '/images/products/shoes-5.jpg',
      category: 'football',
      sport: 'football',
      gender: 'men'
    },
    {
      id: 6,
      name: 'YH Running Pro',
      price: 1399,
      image: '/images/products/shoes-6.jpg',
      category: 'running',
      sport: 'running',
      gender: 'women'
    },
    {
      id: 7,
      name: 'YH Training Flex',
      price: 849,
      image: '/images/products/shoes-7.jpg',
      category: 'training',
      sport: 'training',
      gender: 'men'
    },
    {
      id: 8,
      name: 'YH Casual Wear',
      price: 799,
      image: '/images/products/shoes-8.jpg',
      category: 'lifestyle',
      sport: 'lifestyle',
      gender: 'unisex'
    }
  ];

  const filters = {
    category: [
      { value: 'running', label: t('categories.running') },
      { value: 'training', label: t('categories.training') },
      { value: 'basketball', label: t('categories.basketball') },
      { value: 'football', label: t('categories.football') },
      { value: 'lifestyle', label: t('categories.lifestyle') }
    ],
    sport: [
      { value: 'running', label: t('categories.running') },
      { value: 'training', label: t('categories.training') },
      { value: 'basketball', label: t('categories.basketball') },
      { value: 'football', label: t('categories.football') },
      { value: 'lifestyle', label: t('categories.lifestyle') }
    ],
    gender: [
      { value: 'men', label: 'Men' },
      { value: 'women', label: 'Women' },
      { value: 'unisex', label: 'Unisex' }
    ]
  };

  const sortOptions = [
    { value: 'newest', label: t('filters.newest') },
    { value: 'priceLowToHigh', label: t('filters.priceLowToHigh') },
    { value: 'priceHighToLow', label: t('filters.priceHighToLow') }
  ];

  const formatPrice = (price: number) => {
    return `${price.toLocaleString()} MAD`;
  };

  const handleFilterChange = (filterType: string, value: string) => {
    setActiveFilters(prev => ({
      ...prev,
      [filterType]: value === prev[filterType] ? '' : value
    }));
  };

  const handleClearFilters = () => {
    setActiveFilters({});
  };

  const filteredProducts = products.filter(product => {
    return Object.entries(activeFilters).every(([key, value]) => {
      if (!value) return true;
      return product[key as keyof typeof product] === value;
    });
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'priceLowToHigh') {
      return a.price - b.price;
    } else if (sortBy === 'priceHighToLow') {
      return b.price - a.price;
    }
    // Default to newest (by id in this case)
    return b.id - a.id;
  });

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">{t('header.shop')}</h1>
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Mobile filter dialog */}
          <button
            type="button"
            className="lg:hidden flex items-center justify-center w-full py-2 px-4 border border-gray-300 rounded-md bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 mb-4"
            onClick={() => setShowFilters(!showFilters)}
          >
            <span>{t('filters.title')}</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clipRule="evenodd" />
            </svg>
          </button>
          
          {/* Filters sidebar */}
          <div className={`lg:block ${showFilters ? 'block' : 'hidden'} w-full lg:w-64 flex-shrink-0`}>
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-medium text-gray-900">{t('filters.title')}</h2>
                <button
                  type="button"
                  className="text-sm text-gray-500 hover:text-gray-700"
                  onClick={handleClearFilters}
                >
                  {t('filters.clear')}
                </button>
              </div>
              
              {/* Category filter */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-2">{t('filters.category')}</h3>
                <div className="space-y-2">
                  {filters.category.map((option) => (
                    <div key={option.value} className="flex items-center">
                      <input
                        id={`category-${option.value}`}
                        name="category"
                        type="radio"
                        checked={activeFilters.category === option.value}
                        onChange={() => handleFilterChange('category', option.value)}
                        className="h-4 w-4 border-gray-300 text-black focus:ring-black"
                      />
                      <label htmlFor={`category-${option.value}`} className="ml-3 text-sm text-gray-600">
                        {option.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Sport filter */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-2">{t('filters.sport')}</h3>
                <div className="space-y-2">
                  {filters.sport.map((option) => (
                    <div key={option.value} className="flex items-center">
                      <input
                        id={`sport-${option.value}`}
                        name="sport"
                        type="radio"
                        checked={activeFilters.sport === option.value}
                        onChange={() => handleFilterChange('sport', option.value)}
                        className="h-4 w-4 border-gray-300 text-black focus:ring-black"
                      />
                      <label htmlFor={`sport-${option.value}`} className="ml-3 text-sm text-gray-600">
                        {option.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Gender filter */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-2">{t('filters.gender')}</h3>
                <div className="space-y-2">
                  {filters.gender.map((option) => (
                    <div key={option.value} className="flex items-center">
                      <input
                        id={`gender-${option.value}`}
                        name="gender"
                        type="radio"
                        checked={activeFilters.gender === option.value}
                        onChange={() => handleFilterChange('gender', option.value)}
                        className="h-4 w-4 border-gray-300 text-black focus:ring-black"
                      />
                      <label htmlFor={`gender-${option.value}`} className="ml-3 text-sm text-gray-600">
                        {option.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <button
                type="button"
                className="w-full bg-black text-white py-2 px-4 rounded-md hover:bg-gray-800 transition-colors"
              >
                {t('filters.apply')}
              </button>
            </div>
          </div>
          
          {/* Product grid */}
          <div className="flex-1">
            {/* Sort options */}
            <div className="flex justify-between items-center mb-6">
              <p className="text-sm text-gray-500">
                {sortedProducts.length} {sortedProducts.length === 1 ? 'product' : 'products'}
              </p>
              <div className="flex items-center">
                <span className="text-sm text-gray-700 mr-2">{t('filters.sort')}</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="text-sm border-gray-300 rounded-md focus:ring-black focus:border-black"
                >
                  {sortOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            {/* Products */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedProducts.map((product) => (
                <Link 
                  key={product.id} 
                  href={`/product/${product.id}`}
                  className="group"
                >
                  <div className="relative aspect-square bg-gray-200 rounded-lg overflow-hidden mb-4 transition-all duration-300 group-hover:shadow-lg group-hover:-translate-y-1">
                    <div className="absolute inset-0 bg-gray-200 flex items-center justify-center">
                      {/* Placeholder for product image */}
                      <span className="text-gray-500">{product.name}</span>
                    </div>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
                  <p className="text-gray-700">{formatPrice(product.price)}</p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export const getStaticProps: GetStaticProps = async ({ locale }) => {
  return {
    props: {
      ...(await serverSideTranslations(locale || 'en', ['common'])),
    },
  };
};
